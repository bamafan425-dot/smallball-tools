// SmallBall Club Kit: a small helper that runs inside the trainer page itself, for the Asst. Trainer's buttons.
// SmallBall publishes window.smallballView (turns field spots into screen points) and window.smallballPractice (the
// trainer you're using). The kit's buttons do exactly what your own drag-and-drop does, through the trainer's own
// calls: pick a man up and set him down on a spot (SmallBall then swaps, rests or puts him on deck by its own rules),
// or select him. It only acts when you press a kit button; it never plays, trains or saves anything by itself.
(() => {
  const key = (t) => String(t || "").toLowerCase().replace(/[^a-z0-9]+/g, "");
  const REST = { x: 160, y: 60 };   // inside SmallBall's rest area (foul ground past first base)
  function findMan(f, d) {
    const men = (f.men || []).filter((m) => !m.gone);
    if (d.pid != null) { const m = men.find((m) => String(m.pid) === String(d.pid)); if (m) return m; }
    const want = key(d.name);
    return men.find((m) => key(m.name) === want) || men.find((m) => want && key(m.name) && (key(m.name).startsWith(want) || want.startsWith(key(m.name)))) || null;
  }
  function trainer() { const D = window.smallballPractice; return D && D.active && D.field ? D : null; }
  function place(D, man, spot) {
    const f = D.field, before = new Map(f.men.map((a) => [a.pid, a.spot]));
    let xy;
    if (spot === "REST") xy = REST;
    else if (spot === "BOX" || spot === "DECK") xy = f.spotXY({ spot: "DECK", benchAt: -1 });
    else xy = f.spotXY({ spot, benchAt: -1 });
    if (!xy || !isFinite(xy.x)) return { ok: false, msg: "SmallBall has no " + spot + " spot here." };
    f.hold(man); f.drop(man, xy.x, xy.y);
    try { D.benchSwap(before); } catch (_) {}
    // 🏏 To bat: SmallBall only lets a man reach the box from on deck, so put him on deck and bring him up now,
    // the same step SmallBall takes after 10 pitches (the man who was batting goes back where he came from).
    if (spot === "BOX" && man.spot === "DECK") { try { f.rotateBatter(); } catch (_) {} }
    D.dirty = true;
    const swap = f.men.find((o) => o !== man && before.get(o.pid) === spot && o.spot !== spot);
    return { ok: true, spot: man.spot, sat: !!man.sat, swap: swap ? swap.name : "" };
  }
  window.addEventListener("message", (e) => {
    const d = e.data;
    if (!d || !d.sbxAt || e.source !== window) return;
    let out = null;
    try {
      if (d.sbxAt === "project") {
        const v = window.smallballView; if (v && v.project) out = d.pts.map((p) => { const r = v.project(p[0], p[1], p[2] || 0); return [r.x, r.y]; });
      } else if (d.sbxAt === "send" || d.sbxAt === "focus") {
        const D = trainer();
        if (!D) out = { ok: false, msg: "Open Practice in the trainer first." };
        else {
          const man = findMan(D.field, d);
          if (!man) out = { ok: false, msg: "Couldn't find " + (d.name || "him") + " in the trainer." };
          else if (D.field.held || D.drag) out = { ok: false, msg: "Let go of whoever you're holding first." };
          else if (d.sbxAt === "focus") { D.field.setFocus(man); D.dirty = true; out = { ok: true }; }
          else out = place(D, man, d.spot);
        }
      }
    } catch (err) { out = { ok: false, msg: "SmallBall said no: " + (err && err.message || err) }; }
    window.postMessage({ sbxAtR: d.id, out }, "*");
  });
})();
