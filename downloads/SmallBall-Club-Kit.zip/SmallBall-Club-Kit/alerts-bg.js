// SmallBall Club Kit: 🔔 background alerts (Chrome extension only).
// Every few minutes, even with SmallBall closed, reads the public Hold the Hill data (the same file the Live Hold the
// Hill Leaderboard uses) and pops up a notification when one of your clubs is charged, your charge is about to run
// out, the Bell rings, or a wager comes in. Your clubs come from the kit (it saves them when SmallBall is open).
// It shares a "seen" list with the kit, so you never get the same alert twice. Read-only; nothing is sent anywhere.
const SBX_BG = { alarm: "sbx-alerts", min: 3 };
const RAW = "https://raw.githubusercontent.com/slipnsliders/smallball-tools/main/docs/hill/board.json";
const BOARD = "https://slipnsliders.github.io/smallball-tools/hill/";

chrome.runtime.onInstalled.addListener(() => chrome.alarms.create(SBX_BG.alarm, { periodInMinutes: SBX_BG.min }));
chrome.runtime.onStartup && chrome.runtime.onStartup.addListener(() => chrome.alarms.create(SBX_BG.alarm, { periodInMinutes: SBX_BG.min }));
chrome.alarms.onAlarm.addListener((a) => { if (a.name === SBX_BG.alarm) sbxCheck().catch(() => {}); });
chrome.notifications.onClicked.addListener((id) => {
  chrome.storage.local.get(["sbxAlertUrls"], (r) => {
    const url = ((r && r.sbxAlertUrls) || {})[id] || BOARD;
    chrome.tabs.create({ url });
    chrome.notifications.clear(id);
  });
});

function sbxEvents(H, mine) {
  const ev = [], now = Date.now();
  if (!H || !H.ladder) return ev;
  const all = (H.ace ? [H.ace] : []).concat(H.ladder), me = all.filter((p) => mine.has(String(p.clubId))), names = new Set(me.map((p) => p.name));
  const clubOf = (n) => (all.find((p) => p.name === n) || {}).club || n;
  for (const c of H.charges || []) {
    if (/reported|airing/i.test(c.status || "")) continue;
    const dl = Date.parse(c.deadline || "") || 0;
    if (names.has(c.df)) ev.push({ id: "hc:" + c.created + ":" + c.df, title: "🛡️ You've been charged on the Hill", text: c.ch + " charged " + clubOf(c.df) + (c.type === "Title" ? " for the title" : "") + ". They start the game; be ready." });
    if (names.has(c.ch) && dl && dl - now < 30 * 60000 && dl > now) ev.push({ id: "hd:" + c.created, title: "⏱ Under 30 minutes to play your Hill game", text: "Your charge on " + c.df + " runs out soon. Start a BigLeague game as the visitor." });
  }
  const B = H.bell, climbers = me.filter((p) => Number(p.rank) > 0), ace = me.find((p) => Number(p.rank) === 0);
  if (B && B.open && !B.answered) {
    if (climbers.length) ev.push({ id: "bell:" + B.until, title: "🔔 THE BELL IS RINGING", text: "Anyone on the climb can charge the Ace" + (H.ace ? " (" + H.ace.name + ")" : "") + ". Win by " + (B.margin || 3) + "+ for the title. First one in." });
    else if (ace) ev.push({ id: "bella:" + B.until, title: "🔔 The Bell is ringing: anyone can charge you", text: "They need to win by " + (B.margin || 3) + "+ to take the hill." });
  } else if (B && B.soon && B.next && me.length) ev.push({ id: "bells:" + B.next, title: "🔔 The Bell rings soon", text: "For an hour, anyone on the climb can charge the Ace." });
  for (const w of ((H.wagers || {}).open || [])) {
    if (names.has(w.t)) ev.push({ id: "wg:" + w.id, title: "🤝 " + w.m + " offered you a wager", text: String(w.terms || "").replace(/<[^>]+>/g, "") + ". Answer it on the Master Form." });
  }
  return ev;
}

async function sbxCheck() {
  const st = await chrome.storage.local.get(["sbxAlertCfg", "sbxAlertSeen", "sbxAlertPop", "sbxAlertUrls"]);
  const cfg = st.sbxAlertCfg;
  if (!cfg || !Array.isArray(cfg.own) || !cfg.own.length || st.sbxAlertPop !== true) return;   // only when you turned on desktop pop-ups in the 🔔 inbox
  const r = await fetch(RAW + "?t=" + Math.floor(Date.now() / 60000), { cache: "no-store" });
  if (!r.ok) return;
  const H = await r.json(), ev = sbxEvents(H, new Set(cfg.own.map(String)));
  const seen = st.sbxAlertSeen || {}, urls = st.sbxAlertUrls || {};
  let changed = false;
  for (const e of ev) {
    if (seen[e.id]) continue;
    seen[e.id] = Date.now(); changed = true;
    urls[e.id] = e.id.startsWith("wg:") ? (H.formLink || BOARD) : BOARD;
    chrome.notifications.create(e.id, { type: "basic", iconUrl: "alert-icon.png", title: e.title, message: e.text, priority: 2 });
  }
  if (changed) {
    const cut = Date.now() - 3 * 864e5;
    Object.keys(seen).forEach((k) => { if (seen[k] < cut) { delete seen[k]; delete urls[k]; } });
    await chrome.storage.local.set({ sbxAlertSeen: seen, sbxAlertUrls: urls });
  }
}
// Make sure the check is scheduled whenever the worker wakes up (installs, updates and reloads).
chrome.alarms.get(SBX_BG.alarm, (a) => { if (!a) chrome.alarms.create(SBX_BG.alarm, { periodInMinutes: SBX_BG.min }); });
