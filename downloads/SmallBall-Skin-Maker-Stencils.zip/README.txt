SMALLBALL SKIN MAKER STENCIL PACK
=================================
Free guides for making your own SmallBall stadium skins. Every line in these files is drawn from the
game player's own layout numbers, so what you paint on top lines up with where the players actually stand
and run. There's no SmallBall artwork in this pack: just lines, labels and a grid.

WHAT'S IN HERE
  parkNN-name-guide.png     A labelled guide on a dark background: grid every 50 px, field, bases,
                            mound, foul lines and poles, outfield wall, backstop and scoreboard area.
  parkNN-name-overlay.png   The same lines on a see-through background with no labels. Put it on the
                            top layer while you paint, and hide it before you export.
  contact-sheet.png         All 12 parks at a glance.
  layout.json               The raw numbers, for anyone who wants to build their own tools.

PAINT AT THE PARK'S OWN SIZE
  The player stretches each skin to that park's view size. Most parks are 800×600, but four are not:
    Home field (3)        671×561
    Homerun stadium (4)   700×600
    Letterbox Park (10)   800×450
    Jurassic Park (11)    714×600
  Every guide is already the right size and has it printed in the corner. If you paint at a different
  size, your art gets squashed or stretched to fit.

WHAT THE LINES MEAN
  White diamond, squares   Base paths, home plate, first, second and third base, and the mound.
  White lines, red dots    Foul lines out to the foul poles (distance printed beside each pole).
  Solid gold line          Bottom of the outfield wall, where grass meets wall. This is the line
                           to match.
  Dashed gold line         Top of the wall, from the game's own wall heights. Home runs clear this.
  Blue line                Backstop / edge of the stands behind home (often runs off the bottom).
  Pink box                 Scoreboard. The game draws the count, line score, play text, batting order
                           and lineup on top of this area, so keep it plain and darkish behind the
                           text boxes.
  Green / brown fills      Rough grass and dirt shapes as a starting point. The infield dirt shape
                           is a suggestion, so draw yours however you like.

PERSPECTIVE TIP
  The camera sits up behind home plate looking out. Things get smaller and closer together toward the
  top of the picture, which is why the diamond looks squashed. Follow the grid and the wall lines and
  your art will match the players' perspective.

USING A SKIN
  SmallBall Club Kit (computer editions): ⚙ → Stadium skins → pick the park → Choose image. The kit
  fits it to the park's size and keeps it in your browser only. Open a game at that park to see it.
  Old skins from the original game drop in the same way. Relaunch parks may not match old art pixel
  for pixel, so check one with the overlay first.

Park numbers: 2 League field · 3 Home field · 4 Homerun stadium · 5 World Park · 6 Monster Park ·
7 BrickYard · 8 Alice's Park · 9 Field of Dreams · 10 Letterbox Park · 11 Jurassic Park ·
12 Ocean Park · 13 Centennial Field

Made by Slip for the SmallBall community. Share freely.
